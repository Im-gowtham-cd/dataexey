// Store for tracking downloads (still used for badge count and UI)
let downloadDatabase = {};
let isLoaded = false;
let pendingChecks = new Set();

// Load existing database on startup (for UI/state only)
chrome.runtime.onStartup.addListener(loadDatabase);
chrome.runtime.onInstalled.addListener(loadDatabase);

async function loadDatabase() {
  try {
    const result = await chrome.storage.local.get(['downloadDatabase']);
    downloadDatabase = result.downloadDatabase || {};
    isLoaded = true;
    console.log('Database loaded:', Object.keys(downloadDatabase).length, 'files');
  } catch (error) {
    console.error('Error loading database:', error);
    downloadDatabase = {};
    isLoaded = true;
  }
}

// Monitor all download events
chrome.downloads.onCreated.addListener(async (downloadItem) => {
  console.log('Download created:', downloadItem);
  
  // Wait for database to load
  if (!isLoaded) {
    await loadDatabase();
  }
  
  // Check immediately and periodically for filename
  checkDownloadPeriodically(downloadItem.id);
});

async function checkDownloadPeriodically(downloadId) {
  if (pendingChecks.has(downloadId)) {
    return; // Already checking this download
  }
  
  pendingChecks.add(downloadId);
  
  for (let i = 0; i < 15; i++) { // Try for up to 3 seconds
    try {
      const downloads = await chrome.downloads.search({ id: downloadId });
      
      if (downloads.length === 0) {
        console.log('Download not found, might have been cancelled');
        break;
      }
      
      const download = downloads[0];
      
      // If download is already complete, skip checking
      if (download.state === 'complete') {
        console.log('Download already completed, skipping duplicate check');
        break;
      }
      
      // If we have a filename and it's not cancelled
      if (download.filename && download.state !== 'cancelled') {
        const fileName = getFileName(download.filename);
        
        if (fileName && !fileName.includes('CANCELLED_DUPLICATE')) {
          console.log('Checking for duplicate:', fileName);
          
          // ✅ CRITICAL CHANGE: Search ALL Chrome downloads, not just our database
          const existingFile = await findDuplicateInSystem(fileName, download.totalBytes || 0);
          
          if (existingFile) {
            console.log('DUPLICATE DETECTED:', fileName, 'exists as:', existingFile.name);
            
            // Cancel the download
            try {
              await chrome.downloads.cancel(downloadId);
              console.log('Download cancelled successfully');
            } catch (e) {
              console.error('Could not cancel download:', e);
            }
            
            chrome.notifications.create(`duplicate_${downloadId}`, {
              type: 'basic',
              iconUrl: 'icons/icon48.png',
              title: 'Duplicate Download Blocked!',
              message: `"${fileName}" was already downloaded on ${existingFile.date || 'unknown date'}`,
              buttons: [
                { title: 'View Files' },
                { title: 'Download Anyway' }
              ]
            });

            const pendingKey = `pendingDownload_${downloadId}`;
            const pendingData = {};
            pendingData[pendingKey] = {
              url: download.url,
              filename: fileName,
              originalId: downloadId
            };
            chrome.storage.local.set(pendingData);
            break;
          } else {
            console.log('No duplicate found for:', fileName);
          }
        }
      }

      await new Promise(resolve => setTimeout(resolve, 200));
      
    } catch (error) {
      console.error('Error checking download:', error);
      break;
    }
  }
  
  pendingChecks.delete(downloadId);
}

chrome.downloads.onChanged.addListener(async (delta) => {
  console.log('Download changed:', delta);
  
  if (delta.state && delta.state.current === 'complete') {
    await registerDownload(delta.id);
  }
});

function getFileName(filepath) {
  if (!filepath) return '';
  
  const parts = filepath.split(/[/\\]/);
  let fileName = parts[parts.length - 1] || filepath;
  
  try {
    fileName = decodeURIComponent(fileName);
  } catch (e) {
    console.log('Could not decode filename:', fileName);
  }
  
  return fileName;
}

async function findDuplicateInSystem(fileName, fileSize) {
  if (!fileName) return null;
  
  const normalizedName = normalizeFileName(fileName);
  console.log('Searching system for:', normalizedName);
  
  try {

    const allDownloads = await chrome.downloads.search({
      state: 'complete',
      filenameRegex: '.*' 
    });
    
    console.log(`Found ${allDownloads.length} completed downloads to check against`);
    
    for (const item of allDownloads) {

      if (!item.filename || item.id.toString() === fileName) continue;
      
      const existingName = normalizeFileName(getFileName(item.filename));
      
      if (existingName === normalizedName) {
        console.log('Found exact name match in system!');

        if (fileSize > 0 && item.totalBytes > 0) {
          const sizeDifference = Math.abs(item.totalBytes - fileSize);
          const sizeThreshold = Math.max(1024, Math.min(item.totalBytes, fileSize) * 0.1);
          
          if (sizeDifference <= sizeThreshold) {
            console.log('Size match confirmed duplicate in system');
            return {
              name: getFileName(item.filename),
              size: item.totalBytes,
              date: item.startTime ? new Date(item.startTime).toLocaleDateString() : 'unknown',
              id: item.id
            };
          }
        } else {

          console.log('No size info, matching by name in system');
          return {
            name: getFileName(item.filename),
            size: item.totalBytes || 0,
            date: item.startTime ? new Date(item.startTime).toLocaleDateString() : 'unknown',
            id: item.id
          };
        }
      }

      const similarity = calculateSimilarity(existingName, normalizedName);
      if (similarity >= 0.8) {
        console.log(`Found similar filename (${Math.round(similarity * 100)}% match)`);
        return {
          name: getFileName(item.filename),
          size: item.totalBytes || 0,
          date: item.startTime ? new Date(item.startTime).toLocaleDateString() : 'unknown',
          id: item.id
        };
      }
    }
  } catch (error) {
    console.error('Error searching downloads:', error);
  }
  
  console.log('No duplicate found in system');
  return null;
}

function normalizeFileName(fileName) {
  return fileName.toLowerCase().trim()
    .replace(/\s+/g, ' ')
    .replace(/[^\w\s.-]/g, '');
}

function calculateSimilarity(str1, str2) {
  const longer = str1.length > str2.length ? str1 : str2;
  const shorter = str1.length > str2.length ? str2 : str1;
  
  if (longer.length === 0) return 1.0;
  
  return (longer.length - editDistance(longer, shorter)) / parseFloat(longer.length);
}

function editDistance(s1, s2) {
  s1 = s1.toLowerCase();
  s2 = s2.toLowerCase();
  
  const costs = [];
  for (let i = 0; i <= s1.length; i++) {
    let lastValue = i;
    for (let j = 0; j <= s2.length; j++) {
      if (i === 0) {
        costs[j] = j;
      } else {
        if (j > 0) {
          let newValue = costs[j - 1];
          if (s1.charAt(i - 1) !== s2.charAt(j - 1)) {
            newValue = Math.min(Math.min(newValue, lastValue), costs[j]) + 1;
          }
          costs[j - 1] = lastValue;
          lastValue = newValue;
        }
      }
    }
    if (i > 0) costs[s2.length] = lastValue;
  }
  return costs[s2.length];
}

async function registerDownload(downloadId) {
  try {
    const downloads = await chrome.downloads.search({ id: downloadId });
    if (downloads.length > 0) {
      const download = downloads[0];
      const fileName = getFileName(download.filename);
      
      if (download.state === 'complete' && !download.error && !fileName.includes('CANCELLED_DUPLICATE')) {

        downloadDatabase[downloadId] = {
          name: fileName,
          size: download.totalBytes || download.fileSize || 0,
          path: download.filename,
          url: download.url,
          date: new Date().toLocaleDateString(),
          time: new Date().toLocaleTimeString(),
          timestamp: Date.now()
        };
        
        await chrome.storage.local.set({ downloadDatabase });
        console.log('Registered download:', fileName, 'Total tracked:', Object.keys(downloadDatabase).length);
        updateBadge();
      }
    }
  } catch (error) {
    console.error('Error registering download:', error);
  }
}

function updateBadge() {
  const count = Object.keys(downloadDatabase).length;
  if (count > 0) {
    chrome.action.setBadgeText({ text: count.toString() });
    chrome.action.setBadgeBackgroundColor({ color: '#4285f4' });
  } else {
    chrome.action.setBadgeText({ text: '' });
  }
}	

chrome.notifications.onButtonClicked.addListener(async (notificationId, buttonIndex) => {
  try {
    console.log('Notification button clicked:', notificationId, buttonIndex);
    
    if (buttonIndex === 0) {

      chrome.action.openPopup();
    } else if (buttonIndex === 1) {

      const downloadId = notificationId.replace('duplicate_', '');
      const pendingKey = `pendingDownload_${downloadId}`;
      const result = await chrome.storage.local.get([pendingKey]);
      
      if (result[pendingKey]) {
        console.log('Retrying download:', result[pendingKey]);
        chrome.downloads.download({
          url: result[pendingKey].url,
          filename: result[pendingKey].filename
        });
        chrome.storage.local.remove([pendingKey]);
      }
    }
    chrome.notifications.clear(notificationId);
  } catch (error) {
    console.error('Error handling notification click:', error);
  }
});

loadDatabase();